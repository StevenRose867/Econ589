function ret = Lnorm(data,theta)

ret = -sum((data-theta).^2);