function ret = G(blob)

ind = blob;
ret = (ind>0);