areadata = readmatrix('ass1q7.dat');
thetaguess = q7MLE(areadata);