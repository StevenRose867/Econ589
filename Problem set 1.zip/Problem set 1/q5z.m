function ret = q5z(x,a,theta)
ret = x+2*theta*a;